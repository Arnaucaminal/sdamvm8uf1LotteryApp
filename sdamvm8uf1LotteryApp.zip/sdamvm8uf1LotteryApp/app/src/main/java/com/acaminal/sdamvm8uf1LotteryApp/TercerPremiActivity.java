package com.acaminal.sdamvm8uf1LotteryApp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TercerPremiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultat);


        Button tornarAJugarButton = findViewById(R.id.btTornarAJugar);

        tornarAJugarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Inicia l'activitat principal per a un nou intent de joc
                Intent intent = new Intent(TercerPremiActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
