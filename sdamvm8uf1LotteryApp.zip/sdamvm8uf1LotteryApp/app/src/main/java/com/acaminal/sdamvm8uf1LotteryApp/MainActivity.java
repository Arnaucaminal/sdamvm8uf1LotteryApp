package com.acaminal.sdamvm8uf1LotteryApp;


import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
// ==========================================================================================================
import android.util.Log;
// ==========================================================================================================




public class MainActivity extends AppCompatActivity {
    private EditText[] numberInputs = new EditText[5];
    private Button provaSortButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Inicialitza les caixes d'entrada i el botó
        numberInputs[0] = findViewById(R.id.editTextNumberSigned);
        numberInputs[1] = findViewById(R.id.editTextNumberSigned2);
        numberInputs[2] = findViewById(R.id.editTextNumberSigned3);
        numberInputs[3] = findViewById(R.id.editTextNumberSigned4);
        numberInputs[4] = findViewById(R.id.editTextNumberSigned5);


        provaSortButton = findViewById(R.id.btProvaSort);


        provaSortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sortejar();
            }
        });
    }


    private void sortejar() {
        int numeroGuanyador = 55555; // generarNumeroGuanyador();
        String entradaUsuari = obtenirEntradaUsuari();


        Log.d("Sortejar", "Entrada numeroGuanyador: " + numeroGuanyador);
        Log.d("Sortejar", "Entrada usuari: " + entradaUsuari);


        int coincidencies = compararEntradaAmbNumeroGuanyador(entradaUsuari, numeroGuanyador);


        Log.d("Sortejar", "N coincidencies: " + coincidencies);


        if (coincidencies == 5) {
            mostrarActivitatPrimerPremi();
        } else if (coincidencies == 4) {
            mostrarActivitatSegonPremi();
        } else if (coincidencies == 3) {
            mostrarActivitatTercerPremi();
        } else if (coincidencies == 2) {
            mostrarActivitatQuartPremi();
        } else if (coincidencies == 1) {
            mostrarActivitatCinquePremi();
        } else {
            mostrarActivitatSensePremi();
        }
    }


    private int generarNumeroGuanyador() {
        // Aquí es genera un número aleatori
        int numeroAleatori = (int) (Math.random() * 100000);
        //return numeroAleatori;
        // ==========================================================================================================================
        // https://www.programiz.com/java-programming/library/string/format    EXEMPLE 5
        return Integer.parseInt(String.format("%05d", numeroAleatori));
        // ==========================================================================================================================
    }


    private String obtenirEntradaUsuari() {
        String entrada = "";
        for (EditText editText : numberInputs) {
            try {
                entrada += editText.getText().toString();
            }catch (Exception e){
                entrada += '0';
            }
        }
        return entrada;
    }


    private int compararEntradaAmbNumeroGuanyador(String entradaUsuari, int numeroGuanyador) {
        // Compara les xifres i calcula les coincidències
        int coincidencies = 0;


        for (int i = 4; i >= 0; i--) {
            if (entradaUsuari.charAt(i) == Integer.toString(numeroGuanyador).charAt(i)) {
                coincidencies++;
            } else {
                return coincidencies;
            }
        }
        return coincidencies;
    }


    private void mostrarActivitatPrimerPremi() {
        Intent intent = new Intent(this, ResultatActivity.class);
        startActivity(intent);
    }

    private void mostrarActivitatSegonPremi(){
        Intent intent = new Intent(this, SensePremiActivity.class);
        startActivity(intent);
    }

    private void mostrarActivitatTercerPremi(){
        Intent intent = new Intent(this, TercerPremiActivity.class);
        startActivity(intent);
    }

    private void mostrarActivitatQuartPremi(){
        Intent intent = new Intent(this, QuartPremiActivity.class);
        startActivity(intent);
    }


    private void mostrarActivitatCinquePremi() {
        Intent intent = new Intent(this, CinquePremiActivity.class);
        startActivity(intent);
    }


    private void mostrarActivitatSensePremi() {
        Intent intent = new Intent(this, SensePremiActivity.class);
        startActivity(intent);
    }
}

