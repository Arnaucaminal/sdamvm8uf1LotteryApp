package com.acaminal.sdamvm8uf1LotteryApp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText[] numberInputs = new EditText[5];
    private Button provaSortButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialitza les caixes d'entrada i el botó
        numberInputs[0] = findViewById(R.id.editTextNumberSigned);
        numberInputs[1] = findViewById(R.id.editTextNumberSigned2);
        numberInputs[2] = findViewById(R.id.editTextNumberSigned3);
        numberInputs[3] = findViewById(R.id.editTextNumberSigned4);
        numberInputs[4] = findViewById(R.id.editTextNumberSigned5);

        provaSortButton = findViewById(R.id.btProvaSort);

        provaSortButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sortejar();
            }
        });
    }

    private void sortejar() {
        int numeroGuanyador = generarNumeroGuanyador();
        String entradaUsuari = obtenirEntradaUsuari();

        int coincidencies = compararEntradaAmbNumeroGuanyador(entradaUsuari, numeroGuanyador);

        if (coincidencies == 5) {
            mostrarActivitatPremiGran();
        } else if (coincidencies > 0) {
            mostrarActivitatPremiMenor(coincidencies);
        } else {
            mostrarActivitatSensePremi();
        }
    }

    private int generarNumeroGuanyador() {
        // Aquí es genera un número aleatori
        int numeroAleatori = (int) (Math.random() * 100000);
        return numeroAleatori;
    }

    private String obtenirEntradaUsuari() {
        String entrada = "";
        for (EditText editText : numberInputs) {
            entrada += editText.getText().toString();
        }
        return entrada;
    }

    private int compararEntradaAmbNumeroGuanyador(String entradaUsuari, int numeroGuanyador) {
        // Compara les xifres i calcula les coincidències
        int coincidencies = 0;

        for (int i = 0; i < 5; i++) {
            if (entradaUsuari.charAt(i) == Integer.toString(numeroGuanyador).charAt(i)) {
                coincidencies++;
            }
        }

        return coincidencies;
    }

    private void mostrarActivitatPremiGran() {

    }

    private void mostrarActivitatPremiMenor(int coincidencies) {

    }

    private void mostrarActivitatSensePremi() {

    }
}